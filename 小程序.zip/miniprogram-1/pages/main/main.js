// pages/main/main.js
import { createStoreBindings } from 'mobx-miniprogram-bindings'
import { store } from '../../store/store'
import Dialog from '@vant/weapp/dialog/dialog';
import Notify from '@vant/weapp/notify/notify';

Page({
  /**
   * 页面的初始数据
   */
  data: {
    activeKey: "",
    titleLine: [],
    objectLine: [],
    carLine:[],
    show: false,
    openShow: false,
    way:[],
    value:[],
    current:{},
    sum:0,
    count:0
  },

  mine(){
    wx.navigateTo({
      url: `/pages/mine/mine`
    })
  },

  changeKey(e){
    this.setData({
      activeKey : e.target.id
    })
    this.getObject(e.target.id)
  },

  async openWay(e){
    if(store.openid!==''){
      let res = e.target.dataset.item.way.split(",")
      if(e.target.dataset.item.way!==''){
        await this.setData({
          openShow: true,
          way: res,
          value: [],
          current: e.target.dataset.item
        })
      }else{
        await this.addItem(e.target.dataset.item)
        await this.getCar()
      }
    }else{
      Notify({ type: 'warning', message: '请先登录！' });
    }
  },

  onChange(event) {
    this.setData({
      value: event.detail,
    });
  },

  async confirm(){
    await this.setData({
        openShow: false ,
        current: {
          ...this.data.current,
          way: this.data.value.join(",")
        }
      })
    await this.addItem(this.data.current)
    await this.getCar()
  },

  onClose() {
    this.setData({ openShow: false });
  },

  async addItem(item){
      let count = 0
      this.data.carLine.forEach(obj=>{
      if(obj.name===item.name&&obj.way===item.way){
        count = obj.number+1
        }
      })
      await wx.p.request({
        method: 'GET',
        header: {
          'Authorization': `Bearer ${store.token}`
        },
        url: 'http://localhost:8080/mini/addItem',
        data:{
          openid : store.openid,
          name : item.name,
          photo : item.photo,
          way : item.way,
          number : count?count:1,
          prise : item.prise
        }
      })
  },

  async getCar(){
    let res = await wx.p.request({
      method: 'GET',
      header: {
        'Authorization': `Bearer ${store.token}`
      },
      url: 'http://localhost:8080/mini/getCar',
      data:{
        name: store.openid
      }
    })
    this.setData({
      carLine: res.data.data
    })
    let sum = 0
    let count = 0
    res.data.data.forEach(obj=>{
      sum+=obj.prise*obj.number
      count+=obj.number
    })
    this.setData({
      sum: sum,
      count: count
    })
  },

  async getTitle(){
    let res = await wx.p.request({
      method: 'GET',
      header: {
        'Authorization': `Bearer ${store.token}`
      },
      url: 'http://localhost:8080/mini/getTitle',
    })
    await this.setData({
      titleLine : res.data.data
    })
    await this.setData({
      activeKey : this.data.titleLine[0]
    })
  },

  async getObject(type){
    let res = await wx.p.request({
      method: 'GET',
      header: {
        'Authorization': `Bearer ${store.token}`
      },
      url: 'http://localhost:8080/mini/getObject',
      data:{
        type : type
      }
    })
    this.setData({
      objectLine : res.data.data
    })
  },

  showPopup() {
    if(store.openid!=='')
    {
      this.setData({show:true})
    }else{
      Notify({ type: 'warning', message: '请先登录！' });
    }
  },

  onClose() {
    this.setData({ show: false });
  },

  async minus(e){
    await wx.p.request({
      method: 'GET',
      header: {
        'Authorization': `Bearer ${store.token}`
      },
      url: 'http://localhost:8080/mini/minus',
      data:{
        openid: store.openid,
        name: e.target.dataset.item.name,
        number: e.target.dataset.item.number,
        way: e.target.dataset.item.way
      }
    })
    await this.getCar();
  },

  async plus(e){
    await this.addItem(e.target.dataset.item)
    await this.getCar()
  },

  async crack(){
    await wx.p.request({
      method: 'GET',
      header: {
        'Authorization': `Bearer ${store.token}`
      },
      url: 'http://localhost:8080/mini/crack',
      data: {
        openid: store.openid
      }
    })
    await this.getCar()
  },

  async onSubmit(){
    // 创建一个 Date 对象获取当前时间
    var currentDate = new Date();
    // 获取年、月、日、小时、分钟和秒等信息
    var year = currentDate.getFullYear();
    var month = ('0' + (currentDate.getMonth() + 1)).slice(-2);
    var day = ('0' + currentDate.getDate()).slice(-2);
    var hours = ('0' + currentDate.getHours()).slice(-2);
    var minutes = ('0' + currentDate.getMinutes()).slice(-2);
    var seconds = ('0' + currentDate.getSeconds()).slice(-2);
    var formattedDate = year + '-' + month + '-' + day + ' ' + hours + ':' + minutes + ':' + seconds;

    let nowtime = new Date().getTime().toString()
    let res = await wx.p.request({
      method: 'GET',
      header: {
        'Authorization': `Bearer ${store.token}`
      },
      url: 'http://localhost:8080/mini/addList',
      data: {
        orderId: nowtime,
        openid: store.openid,
        status: "待付款",
        prise: this.data.sum,
        statement:'',
        date: formattedDate
      }
    })
    await this.getCar();
    wx.navigateTo({
      url: `/pages/pay/pay?orderId=${res.data.data}`
    })
  },

  onLoad: function(){
    this.storeBindings = createStoreBindings(this,{
      store,
      fields:['openid','token'],
      actions:['updateOpenid','updateToken']
    })
  },

  /**
   * 生命周期函数--监听页面加载
   */
  async onLoad(options) {
    if(store.openid==='')
    {
      Dialog.alert({
        title: '温馨提示',
        message: '请先授权微信登陆',
      }).then(() => {
        // on close
        wx.redirectTo({
          url: '/pages/login/login',
        })
      })
    }else{
      await this.getTitle()
      await this.getObject(this.data.activeKey)
      await this.getCar()
    }
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady() {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow() {
    
  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide() {

  },

  onUnload: function(){
    this.storeBindings.destroyStoreBindings()
  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload() {
    
  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh() {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom() {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage() {

  }
})