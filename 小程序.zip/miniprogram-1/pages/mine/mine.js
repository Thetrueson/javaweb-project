// pages/mine/mine.js\
import { createStoreBindings } from 'mobx-miniprogram-bindings'
import { store } from '../../store/store'
import Dialog from '@vant/weapp/dialog/dialog';

Page({

  /**
   * 页面的初始数据
   */
  data: {
    list:[]
  },

  careful(e){
    wx.navigateTo({
      url: `/pages/pay/pay?orderId=${e.currentTarget.dataset.list.orderId}`
    })
  },

  onLoad: function(){
    this.storeBindings = createStoreBindings(this,{
      store,
      fields:['openid','token'],
      actions:['updateOpenid','updateToken']
    })
  },

  /**
   * 生命周期函数--监听页面加载
   */
  async onLoad(options) {
    if(store.openid===''){
      Dialog.alert({
        title: '温馨提示',
        message: '请先授权微信登陆',
      }).then(() => {
        // on close
        wx.redirectTo({
          url: '/pages/login/login',
        })
      })
    }else{
      let res = await wx.p.request({
        method: 'GET',
        header: {
          'Authorization': `Bearer ${store.token}`
        },
        url: 'http://localhost:8080/mini/showList',
        data: {
          openid: store.openid
        }
      })
      res.data.data.forEach(element => {
        const date = new Date(element.date);
        const year = date.getFullYear();
        const month = ("0" + (date.getMonth() + 1)).slice(-2);
        const day = ("0" + date.getDate()).slice(-2);
        const hours = ("0" + date.getHours()).slice(-2);
        const minutes = ("0" + date.getMinutes()).slice(-2);
        const seconds = ("0" + date.getSeconds()).slice(-2);
        const formattedTime = `${year}-${month}-${day} ${hours}:${minutes}:${seconds}`
        element.date = formattedTime
      });
      await this.setData({
        list: res.data.data
      }) 
    }
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady() {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow() {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide() {

  },

  onUnload: function(){
    this.storeBindings.destroyStoreBindings()
  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload() {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh() {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom() {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage() {

  }
})