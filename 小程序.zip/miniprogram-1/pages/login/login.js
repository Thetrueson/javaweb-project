// pages/login/login.js
import { createStoreBindings } from 'mobx-miniprogram-bindings'
import { store } from '../../store/store'

Page({

  /**
   * 页面的初始数据
   */
  data: {

  },

  async login(){
    let res = await wx.login()
    res = res.code
    const req = await wx.p.request({
      method: 'GET',
      url: 'http://localhost:8080/mini/login',
      data: {
        code: res
      }
    })
    await store.updateOpenid(req.data.data.openid)
    await store.updateToken(req.data.data.token)
    if(store.openid!=='')
    {
      wx.redirectTo({
      url: '/pages/main/main',
      })
    }
  },

  onLoad: function(){
    this.storeBindings = createStoreBindings(this,{
      store,
      fields:['openid','token'],
      actions:['updateOpenid','updateToken']
    })
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad(options) {

  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady() {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow() {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide() {

  },

  onUnload: function(){
    this.storeBindings.destroyStoreBindings()
  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload() {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh() {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom() {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage() {

  }
})