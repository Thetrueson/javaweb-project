// pages/pay/pay.js
import { createStoreBindings } from 'mobx-miniprogram-bindings'
import { store } from '../../store/store'

Page({

  /**
   * 页面的初始数据
   */
  data: {
    status:'',
    time: 0,
    id:'',
    orderId:'',
    carLine:[],
    message:'',
    sum:0,
    judge:true
  },

  async delete(){
    await wx.p.request({
      method: 'GET',
      header: {
        'Authorization': `Bearer ${store.token}`
      },
      url: 'http://localhost:8080/mini/burst',
      data:{
        orderId: this.data.orderId
      }
    })
    wx.reLaunch({
      url: `/pages/main/main`
    })
  },

  async cancel(){
    await wx.p.request({
      method: 'GET',
      header: {
        'Authorization': `Bearer ${store.token}`
      },
      url: 'http://localhost:8080/mini/cancel',
      data:{
        orderId: this.data.orderId
      }
    })
    wx.reLaunch({
      url: `/pages/main/main`
    })
  },

  async onSubmit(){
    await wx.p.request({
      method: 'GET',
      header: {
        'Authorization': `Bearer ${store.token}`
      },
      url: 'http://localhost:8080/mini/finish',
      data:{
        orderId: this.data.orderId,
        message: this.data.message
      }
    })
    wx.reLaunch({
      url: `/pages/main/main`
    })
  },

  input(e){
    this.setData({message: e.detail})
  },

  async finish(){
    wx.redirectTo({
      url: `/pages/mine/mine`
    })
  },

  onLoad: function(){
    this.storeBindings = createStoreBindings(this,{
      store,
      fields:['openid','token'],
      actions:['updateOpenid','updateToken']
    })
  },

  /**
   * 生命周期函数--监听页面加载
   */
  async onLoad(options) {
    let res = await wx.p.request({
      method: 'GET',
      header: {
        'Authorization': `Bearer ${store.token}`
      },
      url: 'http://localhost:8080/mini/getList',
      data:{
        orderId: options.orderId
      }
    })
    let time =15*60*1000-(new Date().getTime() - parseInt(res.data.data.lists.date))
    if(res.data.data.lists.status !== '待付款'){
      await this.setData({judge: false})
    }
    await this.setData({
      status: res.data.data.lists.status,
      time: time,
      id: res.data.data.lists.orderId,
      sum: res.data.data.lists.prise,
      carLine: res.data.data.itemList,
      orderId: options.orderId,
      message: res.data.data.lists.statement
    })
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady() {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow() {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide() {

  },

  onUnload: function(){
    this.storeBindings.destroyStoreBindings()
  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload() {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh() {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom() {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage() {

  }
})