import {observable, action} from 'mobx-miniprogram'

export const store = observable({
  openid: "",
  token:"",
  updateOpenid:action(function(step){
    this.openid = step
  }),
  updateToken:action(function(step){
    this.token = step
  })
})