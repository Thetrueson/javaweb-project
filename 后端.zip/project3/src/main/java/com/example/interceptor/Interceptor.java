package com.example.interceptor;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.type.TypeFactory;
import io.jsonwebtoken.Claims;
import io.jsonwebtoken.Jwts;
import org.springframework.stereotype.Component;
import org.springframework.web.servlet.HandlerInterceptor;
import org.springframework.web.servlet.ModelAndView;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import java.util.Enumeration;
import java.util.Map;
import java.util.Objects;
import java.util.stream.Collectors;

import static utils.JwtUtils.signKey;

@Component
public class Interceptor implements HandlerInterceptor {
    @Override
    public boolean preHandle(HttpServletRequest req, HttpServletResponse resp, Object handler) throws Exception {

        // 设置允许的请求方法
        resp.setHeader("Access-Control-Allow-Methods", "GET, PUT, POST, DELETE");

        // 设置允许的请求头
        resp.setHeader("Access-Control-Allow-Headers", "Content-Type, Authorization");

        // 设置响应的最大缓存时间
        resp.setHeader("Access-Control-Max-Age", "3600");

        // 设置是否允许发送cookie
        resp.setHeader("Access-Control-Allow-Credentials", "true");

        // 设置允许的源，根据实际需求进行配置
        resp.setHeader("Access-Control-Allow-Origin", "http://localhost:5173");

//        //查看请求头
//        Enumeration<String> headerNames = req.getHeaderNames();
//        while (headerNames.hasMoreElements()) {
//            String headerName = headerNames.nextElement();
//            String headerValue = req.getHeader(headerName);
//            System.out.println(headerName + ": " + headerValue);
//        }

        //不能拦截option请求
        if (req.getMethod().equals("OPTIONS")) {
            resp.setStatus(HttpServletResponse.SC_OK);
            return true;
            // 如果不是，我们就把token拿到，用来做判断
        }

        //判断token
        if (!(req.getRequestURL().toString().contains("/login")||
                req.getRequestURL().toString().contains("/upload"))) {
            String token = req.getHeader("authorization");
            // 验证令牌是否存在及格式是否正确
            if (token != null && token.startsWith("Bearer ")) {
                try {
                    String jwt = token.substring(7); // 去除 "Bearer " 前缀获取纯净的JWT令牌
                    Claims claims = Jwts.parser()
                            .setSigningKey(signKey) // 设置用于验证令牌的密钥
                            .parseClaimsJws(jwt)
                            .getBody();

                    if(!req.getRequestURL().toString().contains("/mini"))
                    {
                        Object statusObj = claims.get("status");
                        String status = statusObj != null ? statusObj.toString() : null;
                        boolean isEqual = Objects.equals(status, "启用");
                        if(isEqual)
                        {
                            return true;
                        }
                        return false;
                    }
                    else{
                        Object statusObj = claims.get("name");
                        String status = statusObj != null ? statusObj.toString() : null;
                        boolean isEqual = Objects.equals(status, "name");
                        if(isEqual)
                        {
                            return true;
                        }
                        return false;
                    }

                } catch (Exception e) {
                    // 令牌验证失败，返回错误信息或执行其他逻辑
                    resp.sendError(HttpServletResponse.SC_UNAUTHORIZED, "无效的token");
                    return false;
                }
            } else {
                // 令牌不存在或格式不正确，返回错误信息或执行其他逻辑
                resp.sendError(HttpServletResponse.SC_UNAUTHORIZED, "错误或无效的token");
                return false;
            }
        }
        return true;
    }
    @Override
    public void postHandle(HttpServletRequest req, HttpServletResponse resp, Object handler, ModelAndView modelAndView) throws Exception {
        // 设置成功状态码
        resp.setStatus(HttpServletResponse.SC_OK);
    }
    }
