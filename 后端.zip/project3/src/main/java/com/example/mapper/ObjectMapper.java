package com.example.mapper;

import com.example.pojo.object.Item;
import com.example.pojo.object.Object;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;

import java.util.List;

@Mapper
public interface ObjectMapper {
    List<String> getOption(@Param("category") String category);
    void addObject(@Param("object") Object object);
    List<Item> showObject(@Param("name") String name, @Param("category") String category, @Param("status") String status);
    void removeObject(@Param("name") String name);
    Object getObject(@Param("name") String name);
    void updateObject(@Param("object") Object object);
    void removeMuch(@Param("list") List<String> list);
}
