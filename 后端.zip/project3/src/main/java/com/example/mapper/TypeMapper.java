package com.example.mapper;

import com.example.pojo.type.Type;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;

import java.util.List;

@Mapper
public interface TypeMapper {
    List<Type> show(@Param("name") String name, @Param("category") String category);
    int changeType(@Param("type") Type type);
    void remove(@Param("name") String name);
    void updateType(@Param("type") Type type);
}
