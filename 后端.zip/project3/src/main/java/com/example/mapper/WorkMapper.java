package com.example.mapper;

import com.example.pojo.trade.Trade;
import org.apache.ibatis.annotations.Mapper;
import org.springframework.format.annotation.DateTimeFormat;

import java.util.Date;
import java.util.List;

@Mapper
public interface WorkMapper {
    public Integer workSum(@DateTimeFormat(pattern = "yyyy-MM-dd HH:mm:ss")Date date);
    public Integer workFinish(@DateTimeFormat(pattern = "yyyy-MM-dd HH:mm:ss")Date date);
    public Integer workOrder(@DateTimeFormat(pattern = "yyyy-MM-dd HH:mm:ss")Date date);
    public Integer workCustomer(@DateTimeFormat(pattern = "yyyy-MM-dd HH:mm:ss")Date date);
    public Integer workPay(@DateTimeFormat(pattern = "yyyy-MM-dd HH:mm:ss")Date date);
    public Integer workCancel(@DateTimeFormat(pattern = "yyyy-MM-dd HH:mm:ss")Date date);
    public Integer workAll(@DateTimeFormat(pattern = "yyyy-MM-dd HH:mm:ss")Date date);
    public Integer workDishOpen(@DateTimeFormat(pattern = "yyyy-MM-dd HH:mm:ss")Date date);
    public Integer workDishClose(@DateTimeFormat(pattern = "yyyy-MM-dd HH:mm:ss")Date date);
    public Integer workGiftOpen(@DateTimeFormat(pattern = "yyyy-MM-dd HH:mm:ss")Date date);
    public Integer workGiftClose(@DateTimeFormat(pattern = "yyyy-MM-dd HH:mm:ss")Date date);
    public List<Trade> workTradeList(@DateTimeFormat(pattern = "yyyy-MM-dd HH:mm:ss")Date date);

}
