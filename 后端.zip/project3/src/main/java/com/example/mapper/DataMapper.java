package com.example.mapper;

import com.example.pojo.data.large.MerChise;
import com.example.pojo.data.large.Prise;
import com.example.pojo.data.little.AllTrade;
import com.example.pojo.data.little.Usrs;
import com.example.pojo.data.little.ValidTrade;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;
import org.springframework.format.annotation.DateTimeFormat;

import java.util.Date;
import java.util.List;

@Mapper
public interface DataMapper {
    public List<Prise> getPrise(@Param("date")Date date);
    public List<Usrs> getUsrs(@Param("date")Date date);
    public List<Usrs> getSum(@Param("date")Date date);
    public List<AllTrade> getAllTrade(@Param("date")Date date);
    public List<ValidTrade> getValidTrade(@Param("date")Date date);
    public List<MerChise> getMerChise(@Param("date")Date date);
}
