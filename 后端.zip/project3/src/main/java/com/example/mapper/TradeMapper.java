package com.example.mapper;

import com.example.pojo.trade.MiniItem;
import com.example.pojo.trade.Trade;
import com.sun.jdi.event.StepEvent;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;

import java.util.Date;
import java.util.List;

@Mapper
public interface TradeMapper {
    public List<Trade> showTrade(@Param("status")String status, @Param("orderId")String orderId, @Param("date1")Date date1, @Param("date2")Date date2);
    public List<MiniItem> getContent(@Param("orderId")String orderId);
    public void finish(@Param("orderId")String orderId);
}
