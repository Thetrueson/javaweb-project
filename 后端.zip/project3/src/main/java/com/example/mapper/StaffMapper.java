package com.example.mapper;

import com.example.pojo.staff.Staff;
import com.example.pojo.staff.User;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;
import java.util.List;

@Mapper
public interface StaffMapper {
    public List<Staff> research(@Param("name") String name);
    public void add(@Param("user") User user);
    public List<Staff> initialStaff();
    public void back(@Param("name") String name);
    public void update(@Param("update") Staff update);
}
