package com.example.mapper;

import com.example.pojo.gift.Gift;
import com.example.pojo.gift.Package;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;

import java.util.List;

@Mapper
public interface GiftMapper {
    void addGift(@Param("object") Gift object);
    List<Package> showGift(@Param("name") String name, @Param("category") String category, @Param("status") String status);
    void removeGift(@Param("name") String name);
    Gift getGift(@Param("name") String name);
    void updateGift(@Param("object") Gift object);
    void removeMany(@Param("list") List<String> list);
}
