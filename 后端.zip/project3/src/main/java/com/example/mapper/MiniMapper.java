package com.example.mapper;

import com.example.pojo.customer.Customer;
import com.example.pojo.list.Lists;
import com.example.pojo.mini.Item;
import com.example.pojo.mini.Mini;
import com.example.pojo.object.Object;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;

import java.util.Date;
import java.util.List;

@Mapper
public interface MiniMapper {
    public List<String> typeList();
    public List<Object> objectList(@Param("type") String type);
    public List<Mini> itemList();
    public void addItem(@Param("item") Item item);
    public void plusItem(@Param("item") Item item);
    public List<Item> getCar(@Param("name") String name);
    public void minus(@Param("openid") String openid,@Param("name") String name,@Param("way") String way);
    public void delete(@Param("openid") String openid,@Param("name") String name,@Param("way") String way);
    public void crack(@Param("openid") String openid);
    public Customer getByOpenid(@Param("openid") String openid);
    public void insert(@Param("customer") Customer customer);
    public void addList(@Param("lists")Lists lists);
    public Lists getList(@Param("orderId") String orderId);
    public void addItems(@Param("items")List<Item> items);
    public List<Item> getItems(@Param("orderId") String orderId);
    public List<Lists> showList(@Param("openid") String openid);
    public void finish(@Param("orderId") String orderId,@Param("message") String message);
    public void changeTask(@Param("date") Date date);
    public void cancel(@Param("orderId")String orderId);
    public void burstList(@Param("orderId")String orderId);
    public void burstItem(@Param("orderId")String orderId);
}
