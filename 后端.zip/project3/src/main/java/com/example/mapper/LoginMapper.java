package com.example.mapper;

import com.example.pojo.staff.User;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;

import java.util.List;

@Mapper
public interface LoginMapper {
    public List<User> login(@Param("number") String number, @Param("password") String password);
    public void choose();
    public int change(@Param("name") String name,@Param("old") String old,@Param("password") String password);
}
