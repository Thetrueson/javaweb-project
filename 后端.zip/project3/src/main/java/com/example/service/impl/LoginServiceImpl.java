package com.example.service.impl;

import com.example.mapper.LoginMapper;
import com.example.pojo.staff.User;
import com.example.service.LoginService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.List;

@Component
public class LoginServiceImpl implements LoginService {
    @Autowired
    public LoginMapper loginMapper;

    public List<User> login(String number, String password)
    {
        List<User> userList = loginMapper.login(number,password);
        return userList;
    }

    public void choose()
    {
        loginMapper.choose();
        return;
    }

    public int change(String name,String old,String password)
    {
        int count = loginMapper.change(name,old,password);
        return count;
    }
}
