package com.example.service;

import com.example.pojo.list.AllList;
import com.example.pojo.list.Lists;
import com.example.pojo.mini.Item;
import com.example.pojo.mini.Mini;
import com.example.pojo.object.Object;
import org.apache.ibatis.annotations.Param;
import org.codehaus.jettison.json.JSONException;

import java.io.IOException;
import java.util.List;

public interface MiniService {
    public List<String> typeList();
    public List<Object> objectList(String type);
    public List<Mini> itemList();
    public void addItem(Item item);
    public List<Item> getCar(String name);
    public void minus(String openid,String name,Integer number,String way);
    public void crack(String openid);
    public String login(String code) throws JSONException, IOException;
    public String addList(Lists lists);
    public AllList getList(String orderId);
    public List<Lists> showList(String openid);
    public void finish(String orderId,String message);
    public void cancel(String orderId);
    public void burst(String orderId);
}
