package com.example.service.impl;

import com.example.mapper.MiniMapper;
import com.example.mapper.TradeMapper;
import com.example.pojo.mini.Mini;
import com.example.pojo.trade.LargeItem;
import com.example.pojo.trade.MiniItem;
import com.example.pojo.trade.PageBean;
import com.example.pojo.trade.Trade;
import com.example.service.TradeService;
import com.github.pagehelper.Page;
import com.github.pagehelper.PageHelper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

@Component
public class TradeServiceImpl implements TradeService {

    @Autowired
    private TradeMapper tradeMapper;
    @Autowired
    private MiniMapper miniMapper;

    public PageBean showTrade(Integer page, Integer pageSize, String status, String orderId, Date date1, Date date2){
        PageHelper.startPage(page,pageSize);
        List<Trade> tradeList = tradeMapper.showTrade(status,orderId,date1,date2);
        for(Trade trade : tradeList)
        {
            List<MiniItem> content = tradeMapper.getContent(trade.getOrderId());
            List<String> list = new ArrayList<>();
            for (MiniItem item : content){
                list.add(item.getName());
            }
            trade.setContent(list);
        }
        Page<Trade> p = (Page<Trade>) tradeList;
        PageBean pageBean = new PageBean(p.getTotal(),p.getResult());
        return pageBean;
    }

    public void finish(String orderId){
        tradeMapper.finish(orderId);
        return;
    }

    public void cancel(String orderId){
        miniMapper.cancel(orderId);
        return;
    }

    public void remove(String orderId){
        miniMapper.burstList(orderId);
        miniMapper.burstItem(orderId);
        return;
    }

    public LargeItem careful(String orderId){
        List<MiniItem> itemList = tradeMapper.getContent(orderId);
        String statement = miniMapper.getList(orderId).getStatement();
        LargeItem list = new LargeItem();
        list.setMiniItem(itemList);
        list.setStatement(statement);
        return list;
    }

}
