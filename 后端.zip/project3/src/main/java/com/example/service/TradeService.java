package com.example.service;

import com.example.pojo.trade.LargeItem;
import com.example.pojo.trade.MiniItem;
import com.example.pojo.trade.PageBean;

import java.util.Date;
import java.util.List;

public interface TradeService {
    public PageBean showTrade(Integer page, Integer pageSize, String status, String orderId, Date date1, Date date2);
    public void finish(String orderId);
    public void cancel(String orderId);
    public void remove(String orderId);
    public LargeItem careful(String orderId);
}
