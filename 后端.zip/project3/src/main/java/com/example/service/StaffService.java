package com.example.service;

import com.example.pojo.staff.PageBean;
import com.example.pojo.staff.Staff;
import com.example.pojo.staff.User;

public interface StaffService {
    public PageBean research(Integer page,Integer pageSize, String name);
    public void add(User user);
    public PageBean initialStaff(Integer page,Integer pageSize);
    public void back(String name);
    public void update(Staff update);
}
