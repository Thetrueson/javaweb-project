package com.example.service.impl;

import com.example.mapper.TypeMapper;
import com.example.pojo.type.PageBean;
import com.example.pojo.type.Type;
import com.github.pagehelper.Page;
import com.github.pagehelper.PageHelper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.List;

@Component
public class TypeServiceImpl {
    @Autowired
    private TypeMapper typeMapper;

    public PageBean show(Integer page, Integer pageSize, String name, String category){
        PageHelper.startPage(page,pageSize);
        List<Type> typeList = typeMapper.show(name,category);
        Page<Type> p = (Page<Type>) typeList;
        PageBean pageBean = new PageBean(p.getTotal(),p.getResult());
        return pageBean;
    }

    public int changeType(Type type)
    {
        int count = typeMapper.changeType(type);
        return count;
    }

    public void remove(String name)
    {
        typeMapper.remove(name);
        return;
    }

    public void updateType(Type type)
    {
        typeMapper.updateType(type);
        return;
    }
}
