package com.example.service.impl;

import com.example.mapper.StaffMapper;
import com.example.pojo.staff.PageBean;
import com.example.pojo.staff.Staff;
import com.example.pojo.staff.User;
import com.example.service.StaffService;
import com.github.pagehelper.Page;
import com.github.pagehelper.PageHelper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.List;

@Component
public class StaffServiceImpl implements StaffService {
    @Autowired
    private StaffMapper staffMapper;

    public PageBean research(Integer page,Integer pageSize, String name){
        PageHelper.startPage(page,pageSize);
        List<Staff> staffList = staffMapper.research(name);
        Page<Staff> p = (Page<Staff>) staffList;
        PageBean pageBean = new PageBean(p.getTotal(),p.getResult());
        return pageBean;
    }

    public void add(User user){
        staffMapper.add(user);
        return;
    }

    public PageBean initialStaff(Integer page,Integer pageSize){
        PageHelper.startPage(page,pageSize);
        List<Staff> staffList = staffMapper.initialStaff();
        Page<Staff> p = (Page<Staff>) staffList;
        PageBean pageBean = new PageBean(p.getTotal(),p.getResult());
        return pageBean;
    }

    public void back(String name)
    {
        staffMapper.back(name);
        return;
    }

    public void update(Staff update){
        staffMapper.update(update);
        return;
    }
}
