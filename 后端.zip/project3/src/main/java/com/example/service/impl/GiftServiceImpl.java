package com.example.service.impl;

import com.example.mapper.GiftMapper;
import com.example.pojo.gift.Gift;
import com.example.pojo.gift.Package;
import com.example.pojo.gift.PageBean;
import com.example.service.GiftService;
import com.github.pagehelper.Page;
import com.github.pagehelper.PageHelper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.List;

@Component
public class GiftServiceImpl implements GiftService {
    @Autowired
    private GiftMapper giftMapper;

    public void addGift(Gift object)
    {
        giftMapper.addGift(object);
        return;
    }

    public PageBean showGift(Integer page, Integer pageSize, String name, String category, String status)
    {
        PageHelper.startPage(page,pageSize);
        List<Package> objectList = giftMapper.showGift(name,category,status);
        Page<Package> p = (Page<Package>) objectList;
        PageBean pageBean = new PageBean(p.getTotal(),p.getResult());
        return pageBean;
    }

    public void removeGift(String name)
    {
        giftMapper.removeGift(name);
        return;
    }

    public Gift getGift(String name)
    {
        Gift objectList = giftMapper.getGift(name);
        return objectList;
    }

    public void updateGift(Gift object)
    {
        giftMapper.updateGift(object);
        return;
    }

    public void removeMany(List<String> list)
    {
        giftMapper.removeMany(list);
        return;
    }
}
