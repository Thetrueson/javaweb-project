package com.example.service.impl;

import com.example.mapper.DataMapper;
import com.example.pojo.data.All;
import com.example.pojo.data.large.BigUsr;
import com.example.pojo.data.large.MerChise;
import com.example.pojo.data.large.Prise;
import com.example.pojo.data.large.Trade;
import com.example.pojo.data.little.AllTrade;
import com.example.pojo.data.little.Usrs;
import com.example.pojo.data.little.ValidTrade;
import com.example.service.DataService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.stereotype.Component;

import java.util.Date;
import java.util.List;

@Component
public class DataServiceImpl implements DataService {

    @Autowired
    private DataMapper dataMapper;

    public All getData(@DateTimeFormat(pattern = "yyyy-MM-dd HH:mm:ss") Date date){
        List<Prise> prise = dataMapper.getPrise(date);
        List<Usrs> usrs = dataMapper.getUsrs(date);
        List<Usrs> sum = dataMapper.getSum(date);
        BigUsr bigUsr = BigUsr.builder()
                .usrs(usrs)
                .sum(sum)
                .build();
        List<AllTrade> allTrade = dataMapper.getAllTrade(date);
        List<ValidTrade> validTrade = dataMapper.getValidTrade(date);
        Trade trade = Trade.builder()
                .allTrade(allTrade)
                .validTrade(validTrade)
                .build();
        List<MerChise> merChise = dataMapper.getMerChise(date);
        All all = All.builder()
                .prise(prise)
                .bigUsr(bigUsr)
                .trade(trade)
                .merChise(merChise)
                .build();
        return all;
    }

}
