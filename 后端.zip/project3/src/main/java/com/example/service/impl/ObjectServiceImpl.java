package com.example.service.impl;

import com.example.mapper.ObjectMapper;
import com.example.pojo.object.Item;
import com.example.pojo.object.Object;
import com.example.pojo.object.PageBean;
import com.example.service.ObjectService;
import com.github.pagehelper.Page;
import com.github.pagehelper.PageHelper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.List;

@Component
public class ObjectServiceImpl implements ObjectService {
    @Autowired
    private ObjectMapper objectMapper;

    public List<String> getOption(String category)
    {
        List<String> options = objectMapper.getOption(category);
        return options;
    }

    public void addObject(Object object)
    {
        objectMapper.addObject(object);
        return;
    }

    public PageBean showObject(Integer page, Integer pageSize, String name, String category, String status)
    {
        PageHelper.startPage(page,pageSize);
        List<Item> objectList = objectMapper.showObject(name,category,status);
        Page<Item> p = (Page<Item>) objectList;
        PageBean pageBean = new PageBean(p.getTotal(),p.getResult());
        return pageBean;
    }

    public void removeObject(String name)
    {
        objectMapper.removeObject(name);
        return;
    }

    public Object getObject(String name)
    {
        Object objectList = objectMapper.getObject(name);
        return objectList;
    }

    public void updateObject(Object object)
    {
        objectMapper.updateObject(object);
        return;
    }

    public void removeMuch(List<String> list)
    {
        objectMapper.removeMuch(list);
        return;
    }
}
