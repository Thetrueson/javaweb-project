package com.example.service.impl;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import com.example.mapper.MiniMapper;
import com.example.pojo.customer.Customer;
import com.example.pojo.list.AllList;
import com.example.pojo.list.Lists;
import com.example.pojo.mini.Item;
import com.example.pojo.mini.Mini;
import com.example.pojo.object.Object;
import com.example.service.MiniService;
import com.example.webSocket.WebSocketServer;
import org.apache.http.client.methods.CloseableHttpResponse;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.impl.client.HttpClients;
import org.apache.http.util.EntityUtils;
import org.apache.ibatis.annotations.Param;
import org.codehaus.jettison.json.JSONException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import javax.swing.*;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.io.IOException;
import java.util.HashMap;
import java.util.List;
import java.util.Date;
import java.util.Map;

@Component
public class MiniServiceImpl implements MiniService {
    @Autowired
    private MiniMapper miniMapper;
    @Autowired
    private WebSocketServer webSocketServer;

    public List<String> typeList(){
        return miniMapper.typeList();
    }

    public List<Object> objectList(String type){
        return miniMapper.objectList(type);
    }

    public List<Mini> itemList(){
        return miniMapper.itemList();
    }

    public void addItem(Item item){
        if(item.getNumber()==1){
            miniMapper.addItem(item);
        }else{
            miniMapper.plusItem(item);
        }
        return;
    }

    public List<Item> getCar(String name){
        List<Item> list = miniMapper.getCar(name);
        return list;
    }

    public void minus(String openid,String name,Integer number,String way){
        if(number == 1){
            miniMapper.delete(openid,name,way);
        }else{
            miniMapper.minus(openid,name,way);
        }
        return;
    }

    public void crack(String openid){
        miniMapper.crack(openid);
        return;
    }

    public String login(String code) throws JSONException, IOException {
//        ("appid","wxfcd03f60125be812");
//        ("secret","f8517849dcbba36e5db48d47a49b557f");
//        ("js_code",code);
//        ("grant_type","authorization_code");
        CloseableHttpClient httpClient = HttpClients.createDefault();
        HttpGet httpGet = new HttpGet("https://api.weixin.qq.com/sns/jscode2session" +
                "?appid=wxfcd03f60125be812" +
                "&secret=f8517849dcbba36e5db48d47a49b557f" +
                "&js_code="+code+
                "&grant_type=authorization_code");
        CloseableHttpResponse response = httpClient.execute(httpGet);
        String json = EntityUtils.toString(response.getEntity());
        response.close();
        httpClient.close();

        JSONObject jsonObject = JSON.parseObject(json);
        String openid = jsonObject.getString("openid");

        Customer customer = miniMapper.getByOpenid(openid);

        if(customer == null){
            customer = Customer.builder()
                    .openid(openid)
                    .date(new Date())
                    .build();
            miniMapper.insert(customer);
        }
        return openid;
    }

    public String addList(Lists lists){
        miniMapper.addList(lists);
        List<Item> itemList = miniMapper.getCar(lists.getOpenid());
        for (Item item : itemList){
            item.setOrderId(lists.getOrderId());
            item.setDate(new Date());
        }
        miniMapper.addItems(itemList);
        miniMapper.crack(lists.getOpenid());
        return lists.getOrderId();
    }

    public AllList getList(String orderId){
        Lists lists = miniMapper.getList(orderId);
        List<Item> itemList = miniMapper.getItems(orderId);
        AllList allList = new AllList();
        allList.setLists(lists);
        allList.setItemList(itemList);
        return allList;
    }

    public List<Lists> showList(String openid){
        List<Lists> listsList = miniMapper.showList(openid);
        return listsList;
    }

    public void finish(String orderId,String message){
        miniMapper.finish(orderId,message);
        Map map = new HashMap<>();
        map.put("orderId",orderId);
        String json = JSON.toJSONString(map);
        webSocketServer.sendToAllClient(json);
        return;
    }

    public void cancel(String orderId){
        miniMapper.cancel(orderId);
        return;
    }

    public void burst(String orderId){
        miniMapper.burstList(orderId);
        miniMapper.burstItem(orderId);
        return;
    }
}
