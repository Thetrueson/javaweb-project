package com.example.service.impl;

import com.example.mapper.WorkMapper;
import com.example.pojo.trade.Trade;
import com.example.pojo.work.Desk;
import com.example.service.WorkService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.stereotype.Component;

import java.util.Date;
import java.util.List;

@Component
public class WorkServiceImpl implements WorkService {

    @Autowired
    private WorkMapper workMapper;

    public Desk workDesk(@DateTimeFormat(pattern = "yyyy-MM-dd HH:mm:ss")Date date){
        int sum = workMapper.workSum(date);
        int finish = workMapper.workFinish(date);
        int order = workMapper.workOrder(date);
        int customer = workMapper.workCustomer(date);
        int pay = workMapper.workPay(date);
        int cancel = workMapper.workCancel(date);
        int all = workMapper.workAll(date);
        int dishOpen = workMapper.workDishOpen(date);
        int dishClose = workMapper.workDishClose(date);
        int giftOpen = workMapper.workGiftOpen(date);
        int giftClose = workMapper.workGiftClose(date);
        List<Trade> tradeList = workMapper.workTradeList(date);
        Desk desk = Desk.builder()
                .sum(sum)
                .finish(finish)
                .order(order)
                .customer(customer)
                .pay(pay)
                .cancel(cancel)
                .all(all)
                .dishOpen(dishOpen)
                .dishClose(dishClose)
                .giftOpen(giftOpen)
                .giftClose(giftClose)
                .tradeList(tradeList)
                .build();
        return desk;
    }
}
