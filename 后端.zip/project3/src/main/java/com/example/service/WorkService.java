package com.example.service;

import com.example.pojo.work.Desk;
import org.springframework.format.annotation.DateTimeFormat;

import java.util.Date;

public interface WorkService {
    public Desk workDesk(@DateTimeFormat(pattern = "yyyy-MM-dd HH:mm:ss")Date date);
}
