package com.example.service;

import com.example.pojo.gift.Gift;
import com.example.pojo.gift.PageBean;

import java.util.List;

public interface GiftService {
    public void addGift(Gift object);
    public PageBean showGift(Integer page,Integer pageSize,String name,String category,String status);
    public void removeGift(String name);
    public Gift getGift(String name);
    public void updateGift(Gift object);
    public void removeMany(List<String> list);
}
