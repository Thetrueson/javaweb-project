package com.example.service;

import com.example.pojo.data.All;
import org.springframework.format.annotation.DateTimeFormat;

import java.util.Date;

public interface DataService {
    public All getData(@DateTimeFormat(pattern = "yyyy-MM-dd HH:mm:ss") Date date);
}
