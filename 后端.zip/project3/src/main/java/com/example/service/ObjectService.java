package com.example.service;

import com.example.pojo.object.Object;
import com.example.pojo.object.PageBean;

import java.util.List;

public interface ObjectService {
    public List<String> getOption(String category);
    public void addObject(Object object);
    public PageBean showObject(Integer page,Integer pageSize,String name,String category,String status);
    public void removeObject(String name);
    public Object getObject(String name);
    public void updateObject(Object object);
    public void removeMuch(List<String> list);
}
