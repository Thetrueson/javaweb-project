package com.example.service;

import com.example.pojo.type.PageBean;
import com.example.pojo.type.Type;

public interface TypeService {
    public PageBean show(Integer page, Integer pageSize, String name, String category);
    public int changeType(Type type);
    public void remove(String name);
    public void updateType(Type type);
}
