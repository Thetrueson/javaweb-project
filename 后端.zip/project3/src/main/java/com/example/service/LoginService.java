package com.example.service;

import com.example.pojo.staff.User;

import java.util.List;

public interface LoginService {
    public List<User> login(String number,String password);
    public void choose();
    public int change(String name,String old,String password);
}
