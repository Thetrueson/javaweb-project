package com.example.common;

import com.example.pojo.Result;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;
import utils.AliOSSUtils;

import java.io.IOException;

@RestController
public class CommonController {
    private AliOSSUtils aliOSSUtils = new AliOSSUtils();

    @RequestMapping("/upload")
    public Result upload(@RequestParam("file") MultipartFile image) throws IOException {
        String url = aliOSSUtils.upload(image);
        return Result.success(url);
    }

}
