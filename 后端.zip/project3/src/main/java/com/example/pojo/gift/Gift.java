package com.example.pojo.gift;

import lombok.Data;

@Data
public class Gift {
    private String name;
    private String photo;
    private String category;
    private Integer prise;
    private String status;
    private String date;
    private String way;
    private String statement;
}
