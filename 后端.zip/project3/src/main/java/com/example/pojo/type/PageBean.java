package com.example.pojo.type;

import com.example.pojo.staff.Staff;
import lombok.Data;

import java.util.List;

@Data
public class PageBean {
    private long total;
    private List<Type> typeList;

    public PageBean(long total,List<Type> typeList)
    {
        this.total = total;
        this.typeList = typeList;
    }
}
