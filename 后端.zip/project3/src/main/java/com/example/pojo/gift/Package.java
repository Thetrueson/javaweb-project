package com.example.pojo.gift;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class Package {
    private String name;
    private String photo;
    private String category;
    private Integer prise;
    private String status;
    private String date;
}