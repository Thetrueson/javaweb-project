package com.example.pojo.type;

import lombok.Data;

@Data
public class Type {
    private String name;
    private String category;
    private Integer sort;
    private String status;
    private String date;
}
