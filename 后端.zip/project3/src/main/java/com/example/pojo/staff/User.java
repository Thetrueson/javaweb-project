package com.example.pojo.staff;

import lombok.Data;

import java.util.Date;

@Data
public class User {
    private String name;
    private String number;
    private String phone;
    private String status;
    private String date;
    private Integer main;
    private String password;
}
