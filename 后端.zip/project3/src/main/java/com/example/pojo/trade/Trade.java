package com.example.pojo.trade;

import lombok.Data;
import org.springframework.format.annotation.DateTimeFormat;

import java.util.Date;
import java.util.List;

@Data
public class Trade {
    private String orderId;
    private List<String> content;
    private String status;
    private Integer prise;
    private String statement;
    @DateTimeFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    private Date date;
}
