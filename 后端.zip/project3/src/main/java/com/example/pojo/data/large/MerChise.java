package com.example.pojo.data.large;

import lombok.Data;

@Data
public class MerChise {
    private String name;
    private Integer number;
}
