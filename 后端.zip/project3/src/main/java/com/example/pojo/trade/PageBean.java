package com.example.pojo.trade;

import lombok.Data;

import java.util.List;

@Data
public class PageBean {
    private long total;
    private List<Trade> tradeList;

    public PageBean(long total, List<Trade> tradeList){
        this.total = total;
        this.tradeList = tradeList;
    }
}
