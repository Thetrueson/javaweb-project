package com.example.pojo.work;

import com.example.pojo.trade.Trade;
import lombok.Builder;
import lombok.Data;

import java.util.List;

@Data
@Builder
public class Desk {
    private Integer sum;
    private Integer finish;
    private Integer order;
    private Integer customer;
    private Integer pay;
    private Integer cancel;
    private Integer all;
    private Integer dishOpen;
    private Integer dishClose;
    private Integer giftOpen;
    private Integer giftClose;
    private List<Trade> tradeList;
}
