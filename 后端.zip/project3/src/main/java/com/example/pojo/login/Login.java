package com.example.pojo.login;

import lombok.Data;

@Data
public class Login {
    private String Name;
    private Integer main;
    private String token;
}
