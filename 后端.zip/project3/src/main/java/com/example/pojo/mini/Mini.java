package com.example.pojo.mini;

import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
public class Mini {
    private String name;
    private String prise;
}
