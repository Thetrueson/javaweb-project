package com.example.pojo.data.large;

import lombok.Data;
import org.springframework.format.annotation.DateTimeFormat;

import java.util.Date;

@Data
public class Prise {
    @DateTimeFormat(pattern = "yyyy-MM-dd")
    private Date day;
    private Integer prise;
}
