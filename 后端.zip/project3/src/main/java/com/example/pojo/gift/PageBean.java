package com.example.pojo.gift;

import com.example.pojo.type.Type;
import lombok.Data;

import java.util.List;

@Data
public class PageBean {
    private long total;
    private List<Package> objectList;

    public PageBean(long total,List<Package> objectList)
    {
        this.total = total;
        this.objectList = objectList;
    }
}
