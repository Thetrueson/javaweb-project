package com.example.pojo.mini;

import lombok.Data;
import lombok.NoArgsConstructor;
import org.springframework.format.annotation.DateTimeFormat;

import java.util.Date;

@Data
@NoArgsConstructor
public class Item {
    private String openid;
    private String name;
    private String photo;
    private String way;
    private Integer number;
    private Integer prise;
    private String orderId;
    @DateTimeFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    private Date date;
}
