package com.example.pojo.data.large;

import com.example.pojo.data.little.Usrs;
import lombok.Builder;
import lombok.Data;

import java.util.List;

@Data
@Builder
public class BigUsr {
    private List<Usrs> usrs;
    private List<Usrs> sum;
}
