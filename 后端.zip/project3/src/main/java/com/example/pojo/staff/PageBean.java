package com.example.pojo.staff;

import lombok.Data;

import java.util.List;

@Data
public class PageBean {
    private long total;
    private List<Staff> staffList;

    public PageBean(long total,List<Staff> staffList)
    {
        this.total = total;
        this.staffList = staffList;
    }
}
