package com.example.pojo.data.large;

import com.example.pojo.data.little.AllTrade;
import com.example.pojo.data.little.ValidTrade;
import lombok.Builder;
import lombok.Data;

import java.util.List;

@Data
@Builder
public class Trade {
    private List<AllTrade> allTrade;
    private List<ValidTrade> validTrade;
}
