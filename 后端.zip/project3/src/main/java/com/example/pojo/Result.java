package com.example.pojo;

import lombok.Data;

@Data
public class Result {
    private Integer code;
    private String msg;
    private Object data;
    public static Result success(Object data)
    {
        Result result = new Result();
        result.data = data;
        result.code=1;
        result.msg="操作成功";
        return result;
    }
    public static Result failure(Object data)
    {
        Result result = new Result();
        result.data = data;
        result.code=0;
        result.msg="操作失败";
        return result;
    }
}
