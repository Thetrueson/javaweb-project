package com.example.pojo.trade;

import lombok.Data;

import java.util.List;

@Data
public class LargeItem {
    private List<MiniItem> miniItem;
    private String statement;
}
