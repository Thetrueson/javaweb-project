package com.example.pojo.data;

import com.example.pojo.data.large.BigUsr;
import com.example.pojo.data.large.MerChise;
import com.example.pojo.data.large.Prise;
import com.example.pojo.data.large.Trade;
import lombok.Builder;
import lombok.Data;

import java.util.List;

@Data
@Builder
public class All {
    private List<Prise> prise;
    private BigUsr bigUsr;
    private Trade trade;
    private List<MerChise> merChise;
}
