package com.example.pojo.object;

import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serializable;

@Data
@NoArgsConstructor
public class Object implements Serializable {
    private String name;
    private String photo;
    private String category;
    private Integer prise;
    private String status;
    private String date;
    private String way;
    private String statement;
}
