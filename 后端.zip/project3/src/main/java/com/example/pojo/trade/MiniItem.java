package com.example.pojo.trade;

import lombok.Data;

import java.util.List;

@Data
public class MiniItem {
    private String name;
    private String way;
    private Integer number;
}
