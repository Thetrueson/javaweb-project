package com.example.pojo.list;

import com.example.pojo.mini.Item;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class AllList {
    private Lists lists;
    private List<Item> itemList;
}
