package com.example.pojo.staff;

import lombok.Data;

import java.sql.Date;

@Data
public class Staff {
    private String name;
    private String number;
    private String phone;
    private String status;
    private String date;
}
