package com.example.pojo.customer;

import lombok.Data;
import org.springframework.format.annotation.DateTimeFormat;

import java.util.Date;

@Data
public class Login {
    private String openid;
    private String token;
}
