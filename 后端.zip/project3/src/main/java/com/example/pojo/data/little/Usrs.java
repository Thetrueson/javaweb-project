package com.example.pojo.data.little;

import lombok.Data;
import org.springframework.format.annotation.DateTimeFormat;

import java.util.Date;

@Data
public class Usrs {
    @DateTimeFormat(pattern = "yyyy-MM-dd")
    private Date day;
    private Integer number;
}
