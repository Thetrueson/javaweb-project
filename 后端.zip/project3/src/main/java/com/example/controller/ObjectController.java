package com.example.controller;

import com.example.pojo.Result;
import com.example.pojo.object.Object;
import com.example.pojo.object.PageBean;
import com.example.service.impl.ObjectServiceImpl;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.redis.core.RedisTemplate;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;
import java.util.Set;

@RestController
public class ObjectController {
    @Autowired
    private ObjectServiceImpl objectServiceImpl;
    @Autowired
    private RedisTemplate redisTemplate;

    @RequestMapping("/getOption")
    public Result getOption(String category)
    {
        List<String> options = objectServiceImpl.getOption(category);
        return Result.success(options);
    }

    @RequestMapping("/addObject")
    public Result addObject(Object object)
    {
        redisTemplate.delete(object.getCategory());
        objectServiceImpl.addObject(object);
        return Result.success(null);
    }

    @RequestMapping("/showObject")
    public Result showObject(@RequestParam(defaultValue = "1")Integer page, @RequestParam(defaultValue = "5")Integer pageSize, String name, String category,String status)
    {
        PageBean objectList = objectServiceImpl.showObject(page,pageSize,name,category,status);
        return Result.success(objectList);
    }

    @RequestMapping("/removeObject")
    public Result removeObject(String name)
    {
        Set keys = redisTemplate.keys("*");
        redisTemplate.delete(keys);
        objectServiceImpl.removeObject(name);
        return Result.success(null);
    }

    @RequestMapping("/getObject")
    public Result getObject(String name)
    {
        Object objectList = objectServiceImpl.getObject(name);
        return Result.success(objectList);
    }

    @RequestMapping("/updateObject")
    public Result updateObject(Object object)
    {
        Set keys = redisTemplate.keys("*");
        redisTemplate.delete(keys);
        objectServiceImpl.updateObject(object);
        return Result.success(null);
    }

    @RequestMapping("/removeMuch/{list}")
    public Result removeMuch(@PathVariable List<String> list)
    {
        Set keys = redisTemplate.keys("*");
        redisTemplate.delete(keys);
        objectServiceImpl.removeMuch(list);
        return Result.success(null);
    }
}
