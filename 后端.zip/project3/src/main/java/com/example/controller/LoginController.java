package com.example.controller;

import com.example.pojo.login.Login;
import com.example.pojo.Result;
import com.example.pojo.staff.User;
import com.example.service.impl.LoginServiceImpl;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.util.DigestUtils;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import utils.JwtUtils;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

@RestController
public class LoginController {
    @Autowired
    private LoginServiceImpl loginServiceImpl;

    @RequestMapping("/login")
    public Result login(String number,String password)
    {
        password = DigestUtils.md5DigestAsHex(password.getBytes());
        List<User> userList= loginServiceImpl.login(number,password);
        if((!userList.isEmpty())&&userList.get(0).getStatus().equals("启用"))
        {
            Map<String,Object> claims = new HashMap<>();
            claims.put("status",userList.get(0).getStatus());
            claims.put("name",userList.get(0).getName());
            claims.put("number",userList.get(0).getNumber());
            String jwt = JwtUtils.generateJwt(claims);
            Login login = new Login();
            login.setName(userList.get(0).getName());
            login.setMain(userList.get(0).getMain());
            login.setToken(jwt);
            return Result.success(login);
        }
        return Result.failure(null);
    }

    @RequestMapping("/choose")
    public Result choose()
    {
        loginServiceImpl.choose();
        return Result.success(null);
    }

    @RequestMapping("/change")
    public Result change(String name,String old,String password)
    {
        old = DigestUtils.md5DigestAsHex(old.getBytes());
        password = DigestUtils.md5DigestAsHex(password.getBytes());
        int count = loginServiceImpl.change(name,old,password);
        if(count>0)
        {
            return Result.success(null);
        }
        return Result.failure(null);
    }
}
