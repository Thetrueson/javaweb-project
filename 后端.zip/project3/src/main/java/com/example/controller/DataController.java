package com.example.controller;

import com.example.pojo.Result;
import com.example.pojo.data.All;
import com.example.pojo.data.large.Prise;
import com.example.service.impl.DataServiceImpl;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.Date;
import java.util.List;

@RestController
public class DataController {

    @Autowired
    private DataServiceImpl dataServiceImpl;

    @RequestMapping("/getData")
    public Result getData(@DateTimeFormat(pattern = "yyyy-MM-dd HH:mm:ss") Date date){
        All all = dataServiceImpl.getData(date);
        return Result.success(all);
    }
}
