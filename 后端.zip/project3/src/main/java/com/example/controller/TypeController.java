package com.example.controller;

import com.example.pojo.Result;
import com.example.pojo.type.PageBean;
import com.example.pojo.type.Type;
import com.example.service.impl.TypeServiceImpl;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.redis.core.RedisTemplate;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class TypeController {
    @Autowired
    private TypeServiceImpl typeServiceImpl;

    @RequestMapping("/show")
    public Result show(@RequestParam(defaultValue = "1")Integer page, @RequestParam(defaultValue = "10")Integer pageSize, String name, String category)
    {
        PageBean typeList = typeServiceImpl.show(page,pageSize,name,category);
        return Result.success(typeList);
    }

    @RequestMapping("/changeType")
    public Result changeType(Type type)
    {
        int count = typeServiceImpl.changeType(type);
        if(count>0)
        {
            return Result.success(null);
        }
        return Result.failure(null);
    }

    @RequestMapping("/remove")
    public Result remove(String name)
    {
        typeServiceImpl.remove(name);
        return Result.success(null);
    }

    @RequestMapping("/updateType")
    public Result updateType(Type type)
    {
        typeServiceImpl.updateType(type);
        return Result.success(null);
    }
}
