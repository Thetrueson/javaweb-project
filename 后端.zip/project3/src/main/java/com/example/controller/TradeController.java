package com.example.controller;

import com.example.pojo.Result;
import com.example.pojo.trade.LargeItem;
import com.example.pojo.trade.MiniItem;
import com.example.pojo.trade.PageBean;
import com.example.service.impl.TradeServiceImpl;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import java.util.Date;
import java.util.List;

@RestController
public class TradeController {

    @Autowired
    private TradeServiceImpl tradeServiceImpl;

    @RequestMapping("/showTrade")
    public Result showTrade(@RequestParam(defaultValue = "1")Integer page, @RequestParam(defaultValue = "5")Integer pageSize,
                                 String status, String orderId,@DateTimeFormat(pattern = "yyyy-MM-dd HH:mm:ss") Date date1,
                                @DateTimeFormat(pattern = "yyyy-MM-dd HH:mm:ss") Date date2 ){
        PageBean tradeList = tradeServiceImpl.showTrade(page,pageSize,status,orderId,date1,date2);
        return Result.success(tradeList);
    }

    @RequestMapping("/finish")
    public Result finish(String orderId){
        tradeServiceImpl.finish(orderId);
        return Result.success(null);
    }

    @RequestMapping("/cancel")
    public Result cancel(String orderId){
        tradeServiceImpl.cancel(orderId);
        return Result.success(null);
    }

    @RequestMapping("/delete")
    public Result remove(String orderId){
        tradeServiceImpl.remove(orderId);
        return Result.success(null);
    }

    @RequestMapping("/careful")
    public Result careful(String orderId){
        LargeItem itemList =  tradeServiceImpl.careful(orderId);
        return Result.success(itemList);
    }
}
