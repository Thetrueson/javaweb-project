package com.example.controller;

import com.example.pojo.Result;
import com.example.pojo.work.Desk;
import com.example.service.impl.WorkServiceImpl;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.Date;

@RestController
public class WorkController {

    @Autowired
    private WorkServiceImpl workServiceImpl;

    @RequestMapping("/workDesk")
    public Result workDesk(@DateTimeFormat(pattern = "yyyy-MM-dd HH:mm:ss") Date date){
        Desk desk = workServiceImpl.workDesk(date);
        return Result.success(desk);
    }

}
