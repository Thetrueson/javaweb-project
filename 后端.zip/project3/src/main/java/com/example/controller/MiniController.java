package com.example.controller;

import com.example.pojo.Result;
import com.example.pojo.customer.Login;
import com.example.pojo.list.AllList;
import com.example.pojo.list.Lists;
import com.example.pojo.mini.Item;
import com.example.pojo.mini.Mini;
import com.example.pojo.object.Object;
import com.example.service.impl.MiniServiceImpl;
import com.example.webSocket.WebSocketServer;
import org.codehaus.jettison.json.JSONException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.redis.core.RedisTemplate;
import org.springframework.web.bind.annotation.*;
import utils.JwtUtils;

import javax.swing.plaf.IconUIResource;
import java.io.IOException;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@RestController
public class MiniController {
    @Autowired
    private MiniServiceImpl miniServiceImpl;
    @Autowired
    private RedisTemplate redisTemplate;

    @RequestMapping("/mini/getTitle")
    public Result typeList()
    {
        List<String> list = miniServiceImpl.typeList();
        return Result.success(list);
    }

    @RequestMapping("/mini/getObject")
    public Result objectList(String type){

        List<Object> list = (List<Object>) redisTemplate.opsForValue().get(type);
        if(list != null&& list.size() > 0)
        {
            return Result.success(list);
        }

        list = miniServiceImpl.objectList(type);
        redisTemplate.opsForValue().set(type,list);

        return Result.success(list);
    }

    @RequestMapping("/mini/getItem")
    public Result itemList(){
        List<Mini> list = miniServiceImpl.itemList();
        return Result.success(list);
    }

    @RequestMapping("/mini/addItem")
    public Result addItem(Item item){
        miniServiceImpl.addItem(item);
        return Result.success(null);
    }

    @RequestMapping("/mini/getCar")
    public Result getCar(String name){
        List<Item> list = miniServiceImpl.getCar(name);
        return Result.success(list);
    }

    @RequestMapping("/mini/minus")
    public Result minus(String openid,String name,Integer number,String way){
        miniServiceImpl.minus(openid,name,number,way);
        return Result.success(null);
    }

    @RequestMapping("/mini/crack")
    public Result crack(String openid){
        miniServiceImpl.crack(openid);
        return Result.success(null);
    }

    @RequestMapping("/mini/login")
    public Result login(String code) throws JSONException, IOException {
        String openid = miniServiceImpl.login(code);
        Map<String, java.lang.Object> claims = new HashMap<>();
        claims.put("id","id");
        claims.put("name","name");
        claims.put("number","number");
        String jwt = JwtUtils.generateJwt(claims);
        Login login = new Login();
        login.setOpenid(openid);
        login.setToken(jwt);
        return Result.success(login);
    }

    @RequestMapping("/mini/addList")
    public Result addList(Lists lists){
        String orderId = miniServiceImpl.addList(lists);
        return Result.success(orderId);
    }

    @RequestMapping("/mini/getList")
    public Result getList(String orderId){
        AllList lists = miniServiceImpl.getList(orderId);
        return Result.success(lists);
    }

    @RequestMapping("/mini/showList")
    public Result showList(String openid){
        List<Lists> lists = miniServiceImpl.showList(openid);
        return Result.success(lists);
    }

    @RequestMapping("/mini/finish")
    public Result finish(String orderId,String message){
        miniServiceImpl.finish(orderId,message);
        return Result.success(null);
    }

    @RequestMapping("/mini/cancel")
    public Result cancel(String orderId){
        miniServiceImpl.cancel(orderId);
        return Result.success(null);
    }

    @RequestMapping("/mini/burst")
    public Result burst(String orderId){
        miniServiceImpl.burst(orderId);
        return Result.success(null);
    }
}
