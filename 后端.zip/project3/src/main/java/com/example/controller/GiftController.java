package com.example.controller;

import com.example.pojo.Result;
import com.example.pojo.gift.Gift;
import com.example.pojo.gift.PageBean;
import com.example.service.impl.GiftServiceImpl;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.redis.core.RedisTemplate;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;
import java.util.Set;

@RestController
public class GiftController {
    @Autowired
    private GiftServiceImpl giftServiceImpl;
    @Autowired
    private RedisTemplate redisTemplate;

    @RequestMapping("/addGift")
    public Result addObject(Gift object)
    {
        redisTemplate.delete(object.getCategory());
        giftServiceImpl.addGift(object);
        return Result.success(null);
    }

    @RequestMapping("/showGift")
    public Result showObject(@RequestParam(defaultValue = "1")Integer page, @RequestParam(defaultValue = "5")Integer pageSize, String name, String category,String status)
    {
        PageBean objectList = giftServiceImpl.showGift(page,pageSize,name,category,status);
        return Result.success(objectList);
    }

    @RequestMapping("/removeGift")
    public Result removeGift(String name)
    {
        Set keys = redisTemplate.keys("*");
        redisTemplate.delete(keys);
        giftServiceImpl.removeGift(name);
        return Result.success(null);
    }

    @RequestMapping("/getGift")
    public Result getGift(String name)
    {
        Gift objectList = giftServiceImpl.getGift(name);
        return Result.success(objectList);
    }

    @RequestMapping("/updateGift")
    public Result updateGift(Gift object)
    {
        Set keys = redisTemplate.keys("*");
        redisTemplate.delete(keys);
        giftServiceImpl.updateGift(object);
        return Result.success(null);
    }

    @RequestMapping("/removeMany/{list}")
    public Result removeMuch(@PathVariable List<String> list)
    {
        Set keys = redisTemplate.keys("*");
        redisTemplate.delete(keys);
        giftServiceImpl.removeMany(list);
        return Result.success(null);
    }
}
