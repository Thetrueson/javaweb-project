package com.example.controller;

import com.example.pojo.Result;
import com.example.pojo.staff.PageBean;
import com.example.pojo.staff.Staff;
import com.example.pojo.staff.User;
import com.example.service.impl.StaffServiceImpl;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.util.DigestUtils;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class StaffController {
    @Autowired
    private StaffServiceImpl staffServiceImpl;

    @RequestMapping("/research")
    public Result research(@RequestParam(defaultValue = "1")Integer page,@RequestParam(defaultValue = "10")Integer pageSize,String name){
        PageBean staffList = staffServiceImpl.research(page,pageSize,name);
        return Result.success(staffList);
    }

    @RequestMapping("/add")
    public Result add(User user){
        user.setPassword(DigestUtils.md5DigestAsHex(user.getPassword().getBytes()));
        staffServiceImpl.add(user);
        return Result.success(null);
    }

    @RequestMapping("/initialStaff")
    public Result initialStaff(@RequestParam(defaultValue = "1")Integer page,@RequestParam(defaultValue = "10")Integer pageSize){
        PageBean staffList = staffServiceImpl.initialStaff(page,pageSize);
        return Result.success(staffList);
    }

    @RequestMapping("/back")
    public Result back(String name){
        staffServiceImpl.back(name);
        return Result.success(null);
    }

    @RequestMapping("/update")
    public Result update(Staff update)
    {
        staffServiceImpl.update(update);
        return Result.success(null);
    }
}
