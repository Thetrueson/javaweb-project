package com.example.task;

import com.example.mapper.MiniMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;

import java.util.Date;

@Component
public class MyTask {

    @Autowired
    private MiniMapper miniMapper;

    @Scheduled(cron= "0 0/1 * * * ?")
    public void executeTask(){
        Date now = new Date();
        long fifteenMinutesInMillis = 15 * 60 * 1000;
        Date fifteenMinutesAgo = new Date(now.getTime() - fifteenMinutesInMillis);
        miniMapper.changeTask(fifteenMinutesAgo);
        return;
    }

}
